#on importe le module Flask et le module nécessaire pour appeler les templates HTML
from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

#on importe la classe Config déclarée dans le fichier config
from .config import Config

#on définit le nom de l'application
app = Flask(__name__,
            #on définit les noms des dossiers template et static, qui sont par défaut 'template' et 'static'
            template_folder='templates',
            static_folder='statics')
app.config.from_object(Config)

db = SQLAlchemy(app)

#pour la connexion des utilisateurs
login = LoginManager(app)

#il faut importer les routes à la toute fin du fichier
from .routes import generales, insertions, suppressions