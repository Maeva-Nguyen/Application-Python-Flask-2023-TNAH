import dotenv
import os

# on récupère le chemin actuel de l'application
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# on charge les variables de .env
dotenv.load_dotenv(os.path.join(BASE_DIR, '.env'))

class Config():
    #les variables d'environnement à aller chercher dans le fichier .env
    #le mode débug
    DEBUG = os.environ.get("DEBUG")
    #le chemin de la base de données
    SQLALCHEMY_DATABASE_URI = os.environ.get("SQLALCHEMY_DATABASE_URI")
    #le nombre de festivals par page
    FESTIVALS_PER_PAGE = os.environ.get("FESTIVALS_PER_PAGE")
    #les variables pour les mots de passe
    SECRET_KEY = os.environ.get("SECRET_KEY")
    WTF_CSRF_ENABLE = os.environ.get("WTF_CSRF_ENABLE")