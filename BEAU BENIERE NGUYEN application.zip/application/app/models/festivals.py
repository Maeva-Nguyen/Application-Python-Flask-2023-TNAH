from ..app import app, db

#la table qui lie festivals et descripteurs, à placer au début du modèle
festival_descripteurs = db.Table(
    "festivals_descripteurs",
    #la liste des colonnes que contient la table
    db.Column('festivalid', db.String(100), db.ForeignKey('festivals.festivalid')),
    db.Column('relation', db.String(100)),
    db.Column('descripteurid', db.Integer, db.ForeignKey('descripteurs.descripteurid'), primary_key=True)
)

#une classe pour chaque table
#la table festivals
class festivals(db.Model):
    #nom de la table
    __tablename__ = "festivals"
    #liste des colonnes
    festivalid = db.Column(db.Integer, primary_key=True)
    identifiant_cnm = db.Column(db.Integer)
    identifiant_agence_a = db.Column(db.String(100))
    nom = db.Column(db.String(100))
    site_internet = db.Column(db.String(100))
    email = db.Column(db.String(100))
    decennie_creation = db.Column(db.String(100))
    annee_creation = db.Column(db.String(100))
    periode = db.Column(db.String(100))
    adresseid = db.Column(db.Integer, db.ForeignKey('adresse.adresseid'))
    envergureid = db.Column(db.Integer, db.ForeignKey('envergure.envergureid'))

    #jointure avec la table festival_descripteurs
    descripteurs = db.relationship(
        'descripteurs', 
        secondary=festival_descripteurs, 
        backref="descripteurs"
    )

    def __repr__(self):
        return '<festivals %r>' % (self.name)


#la table regions
class regions(db.Model):
    regionid = db.Column(db.Integer, primary_key=True)
    label = db.Column(db.String(100))

    #jointure avec la table departements
    departementss = db.relationship(
        'departements',
        backref = 'departementss',
        lazy=True
    )

    def __repr__(self):
        return '<regions %r>' % (self.name)

#la table envergure
class envergure(db.Model):
    envergureid = db.Column(db.Integer, primary_key=True)
    label = db.Column(db.String(100))

    #jointure avec la table festivals
    festivalss = db.relationship(
        'festivals',
        backref = 'festivalss',
        lazy=True
    )

    def __repr__(self):
        return '<envergure %r>' % (self.name)
    

#la table descripteur
class descripteurs(db.Model):
    descripteurid = db.Column(db.Integer, primary_key=True)
    label = db.Column(db.String(100))

    def __repr__(self):
        return '<descripteurs %r>' % (self.name)


#la table departements
class departements(db.Model):
    departementid = db.Column(db.Integer, primary_key=True)
    label = db.Column(db.String(100))
    regionid = db.Column(db.Integer, db.ForeignKey('regions.regionid'))

    #jointure avec la table communes
    communess = db.relationship(
        'communes',
        backref = 'communess',
        lazy=True
    )

    def __repr__(self):
        return '<departements %r>' % (self.name)

#la table communes
class communes(db.Model):
    communeid = db.Column(db.Integer, primary_key=True)
    label = db.Column(db.String(100))
    code_postal = db.Column(db.String(100))
    code_insee_commune = db.Column(db.String(100))
    code_insee_epci = db.Column(db.String(100))
    libelle_epci = db.Column(db.String(100))
    departementid = db.Column(db.String(100), db.ForeignKey('departements.departementid'))

    #jointure avec la table adresse
    adresses = db.relationship(
        'adresse',
        backref = 'adresses',
        lazy=True
    )
    def __repr__(self):
        return '<communes %r>' % (self.name)


#la table adresse
class adresse(db.Model):
    adresseid = db.Column(db.Integer, primary_key=True)
    numero_voie = db.Column(db.String(100))
    type_voie = db.Column(db.String(100))
    nom_voie = db.Column(db.String(100))
    adresse = db.Column(db.String(100))
    complement_adresse = db.Column(db.String(100))
    geocodage = db.Column(db.String(100))
    communeid = db.Column(db.Integer, db.ForeignKey('communes.communeid'))

    #jointure avec la table festivals
    Festivals = db.relationship(
        'festivals',
        backref = 'Festivals',
        lazy=True
    )

    def __repr__(self):
        return '<adresse %r>' % (self.name)