from wtforms import StringField, SelectField, PasswordField
from flask_wtf import FlaskForm

class Recherche(FlaskForm):
    #pour rechercher un festival par son nom/type/région
    nom_festival = StringField("nom_festival", validators=[])
    #pour sélectionner le type de festival : choix entre les 14 premiers types de la base de données
    type = SelectField('type', choices=[('',''), ('Spectacle vivant', 'Spectacle vivant'), ('Cinéma, audiovisuel', 'Cinéma, audiovisuel'), ('Musique', 'Musique'),
                                        ('Livre, littérature', 'Livre, littérature'), ('Pluridisciplinaire', 'Pluridisciplinaire'), ('Arts visuels, arts numériques', 'Arts visuels, arts numériques'),
                                        ('Arts de la rue', 'Arts de la rue'), ('Théâtre', 'Théâtre'), ('Humour', 'Humour'), ('Arts de la piste, théâtre', 'Arts de la piste, théâtre'), ('Spectacle vivant pluridisciplinaire','Spectacle vivant pluridisciplinaire'),
                                        ('Pyrotechnie', 'Pyrotechnie'), ('Arts du cirque', 'Arts du cirque'), ('Pluridisciplinaire à dominante spectacle vivant', 'Pluridisciplinaire à dominante spectacle vivant')])
    #pour sélectionner la région du festival
    region = SelectField('region', choices=[('',''), ('Auvergne-Rhône-Alpes', 'Auvergne-Rhône-Alpes'), ('Provence-Alpes-Côte d Azur', 'Provence-Alpes-Côte d Azur'), ('Corse', 'Corse'), 
                                            ('Occitanie', 'Occitanie'), ('Normandie', 'Normandie'), ('Bretagne', 'Bretagne'), ('Nouvelle-Aquitaine', 'Nouvelle-Aquitaine'),
                                            ('Hauts-de-France','Hauts-de-France'), ('Pays de la Loire', 'Pays de la Loire'), ('Île-de-France', 'Île-de-France'), 
                                            ('Centre-Val de Loire', 'Centre-Val de Loire'), ('Bourgogne-Franche-Comté', 'Bourgogne-Franche-Comté'), ('Grand Est', 'Grand Est'),
                                            ('Guadeloupe', 'Guadeloupe'), ('Nouvelle-Calédonie', 'Nouvelle-Calédonie'), ('La Réunion', 'La Réunion'), 
                                            ('Martinique', 'Martinique'), ('Guyane', 'Guyane'), ('Polynésie française', 'Polynésie française'), ('Mayotte', 'Mayotte'),
                                            ('Saint-Barthélemy', 'Saint-Barthélemy'), ('Saint-Pierre-et-Miquelon', 'Saint-Pierre-et-Miquelon')])
    

class Insertion(FlaskForm):
    #pour insérer un festival
    #écrire le nom du festival
    nom_festival = StringField("nom_festival", validators=[])
    #écrire l'id du festival
    festivalid = StringField("festivalid", validators=[])
    #sélectionner le type du festival parmi les 14 premiers
    type = SelectField('type', choices=[('',''),  ('Spectacle vivant', 'Spectacle vivant'), ('Cinéma, audiovisuel', 'Cinéma, audiovisuel'), ('Musique', 'Musique'),
                                        ('Livre, littérature', 'Livre, littérature'), ('Pluridisciplinaire', 'Pluridisciplinaire'), ('Arts visuels, arts numériques', 'Arts visuels, arts numériques'),
                                        ('Arts de la rue', 'Arts de la rue'), ('Théâtre', 'Théâtre'), ('Humour', 'Humour'), ('Arts de la piste, théâtre', 'Arts de la piste, théâtre'), ('Spectacle vivant pluridisciplinaire','Spectacle vivant pluridisciplinaire'),
                                        ('Pyrotechnie', 'Pyrotechnie'), ('Arts du cirque', 'Arts du cirque'), ('Pluridisciplinaire à dominante spectacle vivant', 'Pluridisciplinaire à dominante spectacle vivant')])
    #sélectionner la région du festival
    region = SelectField('region', choices=[('',''), ('Auvergne-Rhône-Alpes', 'Auvergne-Rhône-Alpes'), ('Provence-Alpes-Côte d Azur', 'Provence-Alpes-Côte d Azur'), ('Corse', 'Corse'), 
                                            ('Occitanie', 'Occitanie'), ('Normandie', 'Normandie'), ('Bretagne', 'Bretagne'), ('Nouvelle-Aquitaine', 'Nouvelle-Aquitaine'),
                                            ('Hauts-de-France','Hauts-de-France'), ('Pays de la Loire', 'Pays de la Loire'), ('Île-de-France', 'Île-de-France'), 
                                            ('Centre-Val de Loire', 'Centre-Val de Loire'), ('Bourgogne-Franche-Comté', 'Bourgogne-Franche-Comté'), ('Grand Est', 'Grand Est'),
                                            ('Guadeloupe', 'Guadeloupe'), ('Nouvelle-Calédonie', 'Nouvelle-Calédonie'), ('La Réunion', 'La Réunion'), 
                                            ('Martinique', 'Martinique'), ('Guyane', 'Guyane'), ('Polynésie française', 'Polynésie française'), ('Mayotte', 'Mayotte'),
                                            ('Saint-Barthélemy', 'Saint-Barthélemy'), ('Saint-Pierre-et-Miquelon', 'Saint-Pierre-et-Miquelon')])
    #écrire la commune du festival
    commune = StringField("commune", validators=[])

class Suppression(FlaskForm):       
    #pour supprimer un festival par son nom 
    nom_festival = StringField("nom_festival", validators=[])


#les classes pour les utilisateurs
#une classe pour ajouter un utilisateur
class AjoutUtilisateur(FlaskForm):
    prenom = StringField("prenom", validators=[])
    password = PasswordField("password", validators=[])

#une classe pour se connecter
class Connexion(FlaskForm):
    prenom = StringField("prenom", validators=[])
    password = PasswordField("password", validators=[])