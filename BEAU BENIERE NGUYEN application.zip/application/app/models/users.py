from ..app import app, db, login
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin

#une classe pour les utilisateurs, qui a été ajoutée dans la base de données
class Users(UserMixin, db.Model):
    __tablename__ = "users"

    #la liste des colonnes de la table (id, prenom et mot de passe)
    id = db.Column(db.Integer, unique=True, nullable=False, primary_key=True, autoincrement=True)
    prenom = db.Column(db.Text, nullable=False)
    password = db.Column(db.String(100), nullable=False)

    @staticmethod
    #une méthode pour ajouter un utilisateur
    def ajout(prenom, password):
        erreurs = []
        if not prenom:
            #le prénom est un champ obligatoire, s'il n'est pas rempli ce message s'affiche : 
            erreurs.append("Le prénom est vide")
            #le mot de passe est obligatoire et doit contenur au minimum 8 caractères : 
        if not password or len(password) < 8:
            erreurs.append("Le mot de passe est vide ou trop court")

        #le nom d'utilisateur doit être unique : 
        #la variable unique stocke le nombre de prenom identiques à celui de l'utilisateur dans la base: 
        unique = Users.query.filter(
            db.or_(Users.prenom == prenom)
        ).count()
        #si la variable est supérieure à 0, le prénom existe déjà dans la base et ne peut être utilisé
        if unique > 0:
            erreurs.append("Le prénom existe déjà")

        #si la longueur de la variable erreurs est supérieure à 0, il faut retourner "erreurs" pour que l'utilisateur puisse lire le message d'erreur
        if len(erreurs) > 0:
            return False, erreurs
        
        utilisateur = Users(
            prenom=prenom,
            #pour que le mot de passe ne soit pas écrit en clair dans la base
            password=generate_password_hash(password)
        )

        try:
            #pour ajouter l'utilisateur
            db.session.add(utilisateur)
            db.session.commit()
            return True, utilisateur
        except Exception as erreur:
            return False, [str(erreur)]
        
    def get_id(self):
        return self.id
    
    #pour connecter l'utilisateur
    @login.user.loader
    def get_user_by_id(id):
        return Users.query.get(int(id))
    
    @staticmethod
    def identification(prenom, password):
        utilisateur = Users.query.filter(Users.prenom == prenom).first()
        #si le bon mot de passe et le bon prénom sont entrés, l'utilisateur est connecté
        if utilisateur and check_password_hash(utilisateur.password, password):
            return utilisateur
        return None
