#Le fichier qui contient les routes
#les imports nécessaires
from flask import render_template, request, flash
from flask_login import login_required
from sqlalchemy import text, or_
from flask_sqlalchemy import SQLAlchemy
from ..app import app, db
from ..models.festivals import festivals, communes, descripteurs, regions, festival_descripteurs, adresse
from ..models.formulaires import Recherche



#les routes / et /home renvoient le template accueil.html
@app.route("/")
@app.route("/home")
def home():
    donnees = []
    #une requête qui affiche nom, période et commune. 
    for Festival in festivals.query.limit(100).all():
        donnees.append({
            
            #requête pour trouver le nom du festival : 
            # SELECT nom FROM festivals
            "nom": festivals.nom,

            #requête pour sélectionner la période : 
            # SELECT periode FROM festivals
            "periode": festivals.periode,

            #la requête SQL pour trouver le nom de la commune : 
            #SELECT communes.label FROM festivals
            #JOIN adresse
            #ON adresse.adresseid = festivals.adresseid
            #JOIN communes
            #ON adresse.communeid = communes.communeid

            "commune": db.session.query(communes.label).select_from(communes).join(adresse.communeid).join(festivals.adresseid).all()
        })
        
    return render_template("pages/accueil.html", donnees=donnees, sous_titre = "Accueil")
    

@app.route("/catalogue/<int:page>")
def catalogue(page):
    #les requêtes SQL
    donnees = []
    for festival in festivals.query.all():
        donnees.append({
            #SELECT nom FROM festivals
            "nom": festivals.nom,

            #SELECT annee_creation FROM festivals
            "annee_creation": festivals.annee_creation,

            #SELECT periode FROM festivals
            "periode": festivals.periode,

            #SELECT communes.label FROM festivals
            #JOIN adresse
            #ON adresse.adresseid = festivals.adresseid
            #JOIN communes
            #ON adresse.communeid = communes.communeid
            "commune": db.session.query(communes.label).select_from(communes).join(adresse.communeid).join(festivals.adresseid).all(),

            #SELECT descripteurs.label FROM descripteurs
            #JOIN festival_descripteurs
            #ON festivals_descripteurs.descripteurid = descripteurs.descripteurid
            #JOIN festivals
            #ON festival_descripteurs.festivalid = festivals.festivalid
            "descripteur": db.session.query(descripteurs.label).select_from(descripteurs).join(festival_descripteurs.descripteurid).join(festivals.festivalid).all()
        })


    #pour paginer
    query = festivals.query
    tous_resultats = query.paginate(page=page, per_page = app.config["FESTIVALS_PER_PAGE"])
    return render_template("pages/catalogue.html", donnees=donnees, sous_titre = "Catalogue")

@app.route("/graphe")
def graphe():
    #trouver comment insérer un graphe avec JS
    return render_template("pages/graphe.html")

@app.route("/annee")
@app.route("/annee/<int:page>")
def annee(page=1):
    #créer une route et un dictionnaire JSON avec les festivals classés par année de création
    festival_par_annee = {}

    for festival in festivals.query.all():
        for festival in festivals.annee_creation:
            if festivals.nom in festival_par_annee:
                if festivals.nom not in festival_par_annee[festivals.nom]:
                    festival_par_annee[festivals.nom] = [festivals.nom]
                
            else : festival_par_annee[festivals.annee_creation] = [festivals.nom]
    return render_template("pages/annee.html", sous_titre = "Année de création", donnees = festivals.query.paginate(page=page, per_page=app.config["FESTIVAL_PER_PAGE"]), donnees_generales = festival_par_annee)




@app.route("/recherche/<int:page>", methods=['GET', 'POST'])
@app.route("/recherche", methods=['GET', 'POST'])
@login_required
#la route pour le formulaire de recherche
def recherche(page=1):
    form = Recherche()
    donnees = []
    try:
        if form.validate_on_submit():
            nom_festival = request.args.get("nom_festival", None)
            type = request.args.get("type", None)
            region = request.args.get("region", None)

            if nom_festival or type or region:
                query_results = festivals.query
        
            if nom_festival:
                #SELECT nom FROM festivals
                #WHERE nom LIKE '%chaine%'
                query_results.filter(festivals.nom.ilike("%"+nom_festival.lower()+"%"))

            if type:
                #SELECT descripteurs.label FROM descripteurs
                #JOIN festival_descripteurs
                #ON descripteurs.descripteurid = festival_descripteurs.descripteurid
                #JOIN festivals
                #ON festivals.festivalid = festival_descripteurs.festivalid
                type = db.session.execute(""" select descripteurs.label from descripteurs
                    inner join festival_descripteurs on festival_descripteurs.descripteurid = descripteurs.descripteurid
                    join festivals on festivals.festivalid = festival_descripteurs.festivalid and descripteurs.label == '"""+type+"""'
                    """).fetchall()
                query_results = query_results.filter(descripteurs.id.in_([t.id for t in type]))
            if region:
                #La requête pour trouver la région en passant par les tables festivals > adresse > communes > departements > regions
                #SELECT regions.label FROM festivals
                #JOIN adresse
                #ON adresse.adresseid = festivals.adresseid
                #JOIN communes
                #ON communes.communeid = adresse.communeid
                #JOIN departements
                #ON departements.departementid = communes.departementid
                #JOIN regions
                #ON regions.regionid = departements.regionid
                region = db.session.execute(""" select regions.label from festivals
                join adresse on adresse.adresseid = festivals.adresseid
                join communes on communes.communeid = adresse.communeid
                join departements on departements.departementid = communes.departementid
                join region on regions.regionid = departements.regionid and
                region == '"""+region+"""'
                """).fetchall()
                query_results = query_results.filter(regions.id.in_([r.id for r in regions] ))
        
            donnees = query_results.order_by(festivals.nom).paginate(page=page, per_page = app.config["FESTIVALS_PER_PAGE"])

            form.nom_festival.data = festivals.nom
            form.region.data = regions.region
            form.type.data = descripteurs.label
        flash("La recherche a été effectuée avec succès", "info")
    except Exception as e:
        flash("La recherche a rencontré une erreur "+str(e), "info")

    return render_template("pages/resultats_recherche.html",
                           sous_titre = "Recherche",
                           donnees = donnees,
                           form = form)



@app.route("/modification", methods=['GET', 'POST'])
@login_required
def modification(nom, nouveau_nom):
    festivals.query.filter(festivals.nom == nom).update({"nom" : nouveau_nom})
    db.session.commit()
    return render_template("pages/modification.html")
