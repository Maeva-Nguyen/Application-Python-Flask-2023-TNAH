from flask import render_template, request, flash
from flask_login import login_required
from sqlalchemy import text, or_
from flask_sqlalchemy import SQLAlchemy
from ..app import app, db
from ..models.festivals import festivals, communes, descripteurs, regions, festival_descripteurs
from ..models.formulaires import Insertion


@app.route("/insertion", methods=['GET', 'POST'])
@login_required
#une route qui nécessite d'être connecté
def insertion():
    #définition de la méthode d'insertion
    form = Insertion()

    #si le formulaire a été validé :
    if form.validate_on_submit():
        #ajouter les données : 
        nom_festival = request.form.get("nom_festival", None)
        festivalid = request.form.get("festivalid", None)
        type = request.form.get("type", None)
        region = request.form.get("region", None)
        commune = request.form.get("commune", None)
        #stocker toutes les données ajoutées dans la variable nouveau_festival
        nouveau_festival = festivals(festivalid = festivalid, nom_festival = nom_festival, region = region, commune = commune, type = type)
        #la variable est ensuite ajoutée à la table festivals
        nouveau_festival.festivals.append(festivals.query.filter(festivals.nom == nom_festival).first())

        db.session.add(nouveau_festival)
        db.session.commit()

    #retour sur la page du template insertion
    return render_template("pages/insertion.html", sous_titre = "Insérer un festival", form=form)