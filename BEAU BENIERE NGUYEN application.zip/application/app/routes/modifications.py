from flask import render_template, request, flash
from flask_login import login_required
from sqlalchemy import text, or_
from flask_sqlalchemy import SQLAlchemy
from ..app import app, db
from ..models.festivals import festivals, communes, descripteurs, regions, festival_descripteurs
from ..models.formulaires import Insertion

@app.route("/modification", methods=['GET', 'POST'])
@login_required
def modification(nom, nouveau_nom):
    festivals.query.filter(festivals.nom == nom).update({"nom" : nouveau_nom})
    db.session.commit()
    return render_template("pages/modification.html")