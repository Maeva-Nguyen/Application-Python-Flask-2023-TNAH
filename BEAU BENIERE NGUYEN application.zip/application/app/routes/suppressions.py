from flask import render_template, request, flash
from flask_login import login_required
from sqlalchemy import text, or_
from flask_sqlalchemy import SQLAlchemy
from ..app import app, db
from ..models.festivals import festivals, communes, descripteurs, regions, festival_descripteurs
from ..models.formulaires import Suppression


@app.route("/suppression", methods=['GET', 'POST'])
#une route qui nécessite d'être connecté
@login_required
#définition de la méthode de suppression
def suppression(nom):
    form = Suppression()
    form.nom_festival.choices = [('','')] + [(festivals.festivalid, festivals.nom) for festival in festivals.query.all()]

    def delete_festival(festival):
        #supprimer le festival via son identifiant
        festival = festivals.query.get(festivals.festivalid)
        if festival : 
            db.session.delete(festival)
            db.session.commit()
        try:
            if form.validate_on_submit():
                nom_festival = request.form.get("nom_festival", None)
                festivalid = request.form.get("festivalid", None)

            elif nom_festival:
                #si la suppression se déroule correctement
                delete_festival(nom_festival)
                flash("La suppression du festival s'est correctement déroulée", 'info')
            
            else:
                #s'il n'y a pas de festival à supprimer
                flash("IL n'y a aucun festival spécifié", "error")
        except Exception as e : 
            flash("Une erreur s'est produite lors de la suppression : " + str(e), "error")
        
        #retour sur le template de suppression
        return render_template("pages/suppression.html", sous_titre = "Suppression d'un festival", form = form)


    festivals.query.filter(festivals.nom == nom).delete()
    db.session.commit()
    return render_template("pages/suppression.html")