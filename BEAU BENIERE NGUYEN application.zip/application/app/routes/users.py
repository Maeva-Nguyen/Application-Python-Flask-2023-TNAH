from flask import url_for, render_template, redirect, request, flash
from ..models.users import Users
from ..models.formulaires import AjoutUtilisateur, Connexion, login
from ..app import app, db
from flask_login import login_user, current_user, logout_user

#route pour ajouter un utilisateur
@app.route("/utilisateurs/ajout", methods=["GET", "POST"])
def ajout_utilisateur():
    form = AjoutUtilisateur()

    #si le formulaire a été validé
    if form.validate_on_submit():
        #ajouter le prénom et le mot de passe
        statut, donnees = Users.ajout(
            prenom=request.form.get("prenom", None),
            password=request.form.get("password", None)
        )
        if statut is True:
            #si cela a fonctionné, retour à l'accueil : 
            flash("Ajout effectué", "success")
            return redirect(url_for("accueil.html"))
        else:
            #si cela n'a pas fonctionné, retour à la page pour ajouter un utilisateur
            flash(",".join(donnees), "error")
            return render_template("pages/ajout_utilisateur.html", form=form)
    else:
        return render_template("pages/ajout_utilisateur.html", form=form)
    
#une route pour se connecter
@app.route("/utilisateurs/connexion", methods=["GET","POST"])
def connexion():
    form = Connexion()

    #si l'utilisateur est connecté : 
    if current_user.is_authenticated is True:
        flash("Vous êtes déjà connecté", "info")
        #retour à l'accueil
        return redirect(url_for("accueil"))

    #si l'utilisateur n'est pas connecté et qu'il a validé le formulaire de connexion : 
    if form.validate_on_submit():
        utilisateur = Users.identification(
            prenom=request.form.get("prenom", None),
            password=request.form.get("password", None)
        )
        #si la connexion a fonctionné
        if utilisateur:
            flash("Connexion effectuée", "success")
            login_user(utilisateur)
            #retour à l'accueil
            return redirect(url_for("accueil"))
        else:
            #si cela n'a pas fonctionné
            flash("Les identifiants n'ont pas été reconnus", "error")
            #retour à la page de connexion
            return render_template("pages/connexion.html", form=form)

    else:
        return render_template("pages/connexion.html", form=form)

login.login_view = 'connexion'

#la route pour se déconnecter
@app.route("/utilisateurs/deconnexion", methods=["POST", "GET"])
def deconnexion():
    #seulement si l'utilisateur est connecté
    if current_user.is_authenticated is True:
        logout_user()
        
    #message qui apparait quand ça a fonctionné et retour à l'accueil : 
    flash("Vous êtes déconnecté", "info")
    return redirect(url_for("accueil.html"))