#le fichier qui permet de lancer l'application dans le terminal.
from app.app import app

if __name__ == "__main__":
    app.run()